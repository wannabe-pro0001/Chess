
from turtle import Screen
import pygame
import button
import giaodien
from tkinter import *  
import pandas as pd
import csv

white = [255, 0, 255]
red=(255,0,0)
pygame.init()
width,height =600,700
screen = pygame.display.set_mode((width,height))



#load button images

new_img = pygame.image.load('nutnew1.png').convert_alpha()
back_img= pygame.image.load('nutback1.png').convert_alpha()
exit_img = pygame.image.load('nutexit1.png').convert_alpha()
next_img = pygame.image.load('nutnext1.png').convert_alpha()

blue = (0, 0, 128)

def resize(image,scale):
    x=image.get_width()
    y=image.get_height()
    image = pygame.transform.scale(image, (x*scale, y*scale))
    return image


new_img =resize(new_img,0.3)
back_img=resize(back_img,0.3)
exit_img =resize(exit_img,0.3)
next_img =resize(next_img,0.3)
font = pygame.font.Font('freesansbold.ttf', 20)

def label(x,y,infofation):
    text = font.render(infofation, True, blue, None)
    textRect = text.get_rect()
    textRect.center = (x,y)
    return text,textRect

a,b=label(130,670,'New')
c,d=label(230,670,'Back')
e,f=label(330,670,'Exit')
g,h=label(430,670,'Next')



#create button instances

new_button = button.Button(100,600, new_img, 0.8)
back_button = button.Button(200, 600, back_img, 0.8)
exit_button = button.Button(300, 600, exit_img, 0.8)
next_button = button.Button(400, 600, next_img, 0.8)


#game loop
myfont = pygame.font.SysFont("monospace", 22)


     
def main():
    run = True
    while run:
        screen.fill(white)
        screen.blit(a,b)
        screen.blit(c,d)
        screen.blit(e,f)
        screen.blit(g,h)


    
            

       
            
        if new_button.draw(screen):
            print('new')
        if back_button.draw(screen):
            print('Back')
        if exit_button.draw(screen):
            run=False
        if next_button.draw(screen):
            print('next')

        #event handler
        for event in pygame.event.get():
            #quit game
            if event.type == pygame.QUIT:
                run = False
            
        pygame.display.update()

if __name__ == '__main__':
    main()
    pygame.quit()
    


